#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_err.h"
#include "esp_log.h"
#include "esp_system.h"
#include "esp_vfs.h"
#include "esp_spiffs.h"

#include "st7789.h"
#include "st7789_tools.h"
#include "fontx.h"
#include "bmpfile.h"
#include "decode_jpeg.h"
#include "decode_png.h"
#include "pngle.h"

#define CONFIG_WIDTH  240
#define CONFIG_HEIGHT 240
#define CONFIG_RESET_GPIO 15
#define CONFIG_SCLK_GPIO 18
#define CONFIG_DC_GPIO 19
#define CONFIG_MOSI_GPIO 23
#define CONFIG_BL_GPIO -1
#define CONFIG_CS_GPIO -1
#define CONFIG_OFFSETX 0
#define CONFIG_OFFSETY 0




void ST7789(void *pvParameters)
{
  FontxFile fx16G[2];
  FontxFile fx24G[2];
  FontxFile fx32G[2];
  FontxFile fx32L[2];
  InitFontx(fx16G,"/spiffs/ILGH16XB.FNT",""); // 8x16Dot Gothic
  InitFontx(fx24G,"/spiffs/ILGH24XB.FNT",""); // 12x24Dot Gothic
  InitFontx(fx32G,"/spiffs/ILGH32XB.FNT",""); // 16x32Dot Gothic
  InitFontx(fx32L,"/spiffs/LATIN32B.FNT",""); // 16x32Dot Latin

  FontxFile fx16M[2];
  FontxFile fx24M[2];
  FontxFile fx32M[2];
  InitFontx(fx16M,"/spiffs/ILMH16XB.FNT",""); // 8x16Dot Mincyo
  InitFontx(fx24M,"/spiffs/ILMH24XB.FNT",""); // 12x24Dot Mincyo
  InitFontx(fx32M,"/spiffs/ILMH32XB.FNT",""); // 16x32Dot Mincyo

  TFT_t dev;
  spi_master_init(&dev, CONFIG_MOSI_GPIO, CONFIG_SCLK_GPIO, CONFIG_CS_GPIO, CONFIG_DC_GPIO, CONFIG_RESET_GPIO, CONFIG_BL_GPIO);
  lcdInit(&dev, CONFIG_WIDTH, CONFIG_HEIGHT, CONFIG_OFFSETX, CONFIG_OFFSETY);

  lcdFillScreen(&dev, WHITE);

  while(1) {

    JPEGReader(&dev, "/spiffs/esp32.jpeg", CONFIG_WIDTH, CONFIG_HEIGHT);
    vTaskDelay(400);
    lcdFillScreen(&dev, WHITE);

    lcdAddStringRow(&dev, fx24G, BLACK, 0, "Basic...", 3);
    lcdAddStringXY(&dev, fx24G, BLACK, 0, "Basic...", 120, 120);
    vTaskDelay(400);

    PNGReader(&dev, "/spiffs/esp_logo.png", CONFIG_WIDTH, CONFIG_HEIGHT);
    vTaskDelay(400);

    char* str[10] = {"12345678901234567890", "TEST2", "TEST3", "TEST4", "TEST5", "TEST6", "TEST7", "TEST8", "TEST9", "TEST10"};
    lcdAddStringList(&dev, fx24G, BLUE, 0, &str, 10);
    vTaskDelay(2000);

  }
  return;
}

static void SPIFFS_Directory(char * path) {
  DIR* dir = opendir(path);
  assert(dir != NULL);
  while (true) {
    struct dirent*pe = readdir(dir);
    if (!pe) break;
    ESP_LOGI(TAG, "文件名=%s 节点编号=%d 文件类型=%x", pe->d_name,pe->d_ino, pe->d_type);
  }
  closedir(dir);
}

void mount_SPIFFS()
{
  ESP_LOGI(TAG, "初始化 SPIFFS");
  esp_vfs_spiffs_conf_t conf = {
    .base_path = "/spiffs",
    .partition_label = NULL,
    .max_files = 12,
    .format_if_mount_failed =true
  };
  // 使用上面定义的设置来初始化和挂载 SPIFFS 文件系统
  esp_err_t ret = esp_vfs_spiffs_register(&conf);
  if (ret != ESP_OK) {
    if (ret == ESP_FAIL) {
      ESP_LOGI(TAG, "无法挂载或格式化文件系统");
    } else if (ret == ESP_ERR_NOT_FOUND) {
      ESP_LOGI(TAG, "找不到 SPIFFS 分区");
    } else {
      ESP_LOGI(TAG, "无法初始化 SPIFFS (%s)",esp_err_to_name(ret));
    }
    return;
  }
  size_t total = 0, used = 0;
  ret = esp_spiffs_info(NULL, &total,&used);
  if (ret != ESP_OK) {
    ESP_LOGI(TAG, "无法获取 SPIFFS 分区信息 (%s)",esp_err_to_name(ret));
  } else {
    ESP_LOGI(TAG, "分区大小总计: %d, 已用容量: %d", total, used);
  }
  SPIFFS_Directory("/spiffs/");
}

void app_main(void)
{
  mount_SPIFFS();
  xTaskCreate(ST7789, "ST7789", 1024*6, NULL, 2, NULL);
}