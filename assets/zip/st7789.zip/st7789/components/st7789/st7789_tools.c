#include <string.h>
#include <inttypes.h>
#include <math.h>
#include "esp_log.h"
#include "st7789.h"
#include "st7789_tools.h"
#include "fontx.h"
#include "bmpfile.h"
#include "decode_jpeg.h"
#include "decode_png.h"
#include "pngle.h"

//----------------------------------------------
// 绘制填充颜色的矩形
void lcdDrawFillRect(TFT_t * dev, uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t color) {
  if (x1 >= dev->_width) return;
  if (x2 >= dev->_width) x2=dev->_width-1;
  if (y1 >= dev->_height) return;
  if (y2 >= dev->_height) y2=dev->_height-1;

  ESP_LOGD(TAG,"offset(x)=%d offset(y)=%d",dev->_offsetx,dev->_offsety);
  if (dev->_use_frame_buffer) {
    for (int16_t j = y1; j <= y2; j++){
      for(int16_t i = x1; i <= x2; i++){
        dev->_frame_buffer[j*dev->_width+i] = color;
      }
    }
  } else {
    uint16_t _x1 = x1 + dev->_offsetx;
    uint16_t _x2 = x2 + dev->_offsetx;
    uint16_t _y1 = y1 + dev->_offsety;
    uint16_t _y2 = y2 + dev->_offsety;
    spi_master_write_command(dev, 0x2A);  // 设置列 (x) 地址
    spi_master_write_addr(dev, _x1, _x2);
    spi_master_write_command(dev, 0x2B);  // 设置页面 (y) 地址
    spi_master_write_addr(dev, _y1, _y2);
    spi_master_write_command(dev, 0x2C);  // 内存写入
    for(int i=_x1;i<=_x2;i++){
      uint16_t size = _y2-_y1+1;
      spi_master_write_color(dev, color, size);
    }
  }
}

// 绘制填充颜色的正方形
void lcdDrawFillSquare(TFT_t * dev, uint16_t x0, uint16_t y0, uint16_t size, uint16_t color) {
  uint16_t x1 = x0-size;
  uint16_t y1 = y0-size;
  uint16_t x2 = x0+size;
  uint16_t y2 = y0+size;
  lcdDrawFillRect(dev, x1, y1, x2, y2, color);
}

// 用颜色画线
void lcdDrawLine(TFT_t * dev, uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t color) {
  int i;
  int dx,dy;
  int sx,sy;
  int E;

  // 计算两点之间的距离
  dx = ( x2 > x1 ) ? x2 - x1 : x1 - x2;
  dy = ( y2 > y1 ) ? y2 - y1 : y1 - y2;

  // 检查两点的方向
  sx = ( x2 > x1 ) ? 1 : -1;
  sy = ( y2 > y1 ) ? 1 : -1;

  // 倾角 < 1
  if ( dx > dy ) {
    E = -dx;
    for ( i = 0 ; i <= dx ; i++ ) {
      lcdDrawPixel(dev, x1, y1, color);
      x1 += sx;
      E += 2 * dy;
      if ( E >= 0 ) {
      y1 += sy;
      E -= 2 * dx;
    }
  }

  // 倾角 >= 1
  } else {
    E = -dy;
    for ( i = 0 ; i <= dy ; i++ ) {
      lcdDrawPixel(dev, x1, y1, color);
      y1 += sy;
      E += 2 * dx;
      if ( E >= 0 ) {
        x1 += sx;
        E -= 2 * dy;
      }
    }
  }
}

// 用颜色画出矩形
void lcdDrawRect(TFT_t * dev, uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t color) {
  lcdDrawLine(dev, x1, y1, x2, y1, color);
  lcdDrawLine(dev, x2, y1, x2, y2, color);
  lcdDrawLine(dev, x2, y2, x1, y2, color);
  lcdDrawLine(dev, x1, y2, x1, y1, color);
}

// 用角度和颜色绘制矩形
void lcdDrawRectAngle(TFT_t * dev, uint16_t xc, uint16_t yc, uint16_t w, uint16_t h, uint16_t angle, uint16_t color) {
  double xd,yd,rd;
  int x1,y1;
  int x2,y2;
  int x3,y3;
  int x4,y4;
  rd = -angle * M_PI / 180.0;
  xd = 0.0 - w/2;
  yd = h/2;
  x1 = (int)(xd * cos(rd) - yd * sin(rd) + xc);
  y1 = (int)(xd * sin(rd) + yd * cos(rd) + yc);
  yd = 0.0 - yd;
  x2 = (int)(xd * cos(rd) - yd * sin(rd) + xc);
  y2 = (int)(xd * sin(rd) + yd * cos(rd) + yc);
  xd = w/2;
  yd = h/2;
  x3 = (int)(xd * cos(rd) - yd * sin(rd) + xc);
  y3 = (int)(xd * sin(rd) + yd * cos(rd) + yc);
  yd = 0.0 - yd;
  x4 = (int)(xd * cos(rd) - yd * sin(rd) + xc);
  y4 = (int)(xd * sin(rd) + yd * cos(rd) + yc);
  lcdDrawLine(dev, x1, y1, x2, y2, color);
  lcdDrawLine(dev, x1, y1, x3, y3, color);
  lcdDrawLine(dev, x2, y2, x4, y4, color);
  lcdDrawLine(dev, x3, y3, x4, y4, color);
}

// 用颜色画出三角形
void lcdDrawTriangle(TFT_t * dev, uint16_t xc, uint16_t yc, uint16_t w, uint16_t h, uint16_t angle, uint16_t color) {
  double xd,yd,rd;
  int x1,y1;
  int x2,y2;
  int x3,y3;
  rd = -angle * M_PI / 180.0;
  xd = 0.0;
  yd = h/2;
  x1 = (int)(xd * cos(rd) - yd * sin(rd) + xc);
  y1 = (int)(xd * sin(rd) + yd * cos(rd) + yc);
  xd = w/2;
  yd = 0.0 - yd;
  x2 = (int)(xd * cos(rd) - yd * sin(rd) + xc);
  y2 = (int)(xd * sin(rd) + yd * cos(rd) + yc);
  xd = 0.0 - w/2;
  x3 = (int)(xd * cos(rd) - yd * sin(rd) + xc);
  y3 = (int)(xd * sin(rd) + yd * cos(rd) + yc);
  lcdDrawLine(dev, x1, y1, x2, y2, color);
  lcdDrawLine(dev, x1, y1, x3, y3, color);
  lcdDrawLine(dev, x2, y2, x3, y3, color);
}

// 用颜色绘制正多边形
void lcdDrawRegularPolygon(TFT_t *dev, uint16_t xc, uint16_t yc, uint16_t n, uint16_t r, uint16_t angle, uint16_t color)
{
  double xd, yd, rd;
  int x1, y1;
  int x2, y2;
  int i;

  rd = -angle * M_PI / 180.0;
  for (i = 0; i < n; i++)
  {
    xd = r * cos(2 * M_PI * i / n);
    yd = r * sin(2 * M_PI * i / n);
    x1 = (int)(xd * cos(rd) - yd * sin(rd) + xc);
    y1 = (int)(xd * sin(rd) + yd * cos(rd) + yc);

    xd = r * cos(2 * M_PI * (i + 1) / n);
    yd = r * sin(2 * M_PI * (i + 1) / n);
    x2 = (int)(xd * cos(rd) - yd * sin(rd) + xc);
    y2 = (int)(xd * sin(rd) + yd * cos(rd) + yc);

    lcdDrawLine(dev, x1, y1, x2, y2, color);
  }
}

// 用颜色画圆
void lcdDrawCircle(TFT_t * dev, uint16_t x0, uint16_t y0, uint16_t r, uint16_t color) {
  int x;
  int y;
  int err;
  int old_err;

  x=0;
  y=-r;
  err=2-2*r;
  do{
    lcdDrawPixel(dev, x0-x, y0+y, color); 
    lcdDrawPixel(dev, x0-y, y0-x, color); 
    lcdDrawPixel(dev, x0+x, y0-y, color); 
    lcdDrawPixel(dev, x0+y, y0+x, color); 
    if ((old_err=err)<=x)  err+=++x*2+1;
    if (old_err>y || err>x) err+=++y*2+1;   
  } while(y<0);
}

// 画一个圆圈并填充颜色
void lcdDrawFillCircle(TFT_t * dev, uint16_t x0, uint16_t y0, uint16_t r, uint16_t color) {
  int x;
  int y;
  int err;
  int old_err;
  int ChangeX;

  x=0;
  y=-r;
  err=2-2*r;
  ChangeX=1;
  do{
    if(ChangeX) {
      lcdDrawLine(dev, x0-x, y0-y, x0-x, y0+y, color);
      lcdDrawLine(dev, x0+x, y0-y, x0+x, y0+y, color);
    } // endif
    ChangeX=(old_err=err)<=x;
    if (ChangeX)      err+=++x*2+1;
    if (old_err>y || err>x) err+=++y*2+1;
  } while(y<=0);
} 

// 用颜色画出圆角矩形
void lcdDrawRoundRect(TFT_t * dev, uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t r, uint16_t color) {
  int x;
  int y;
  int err;
  int old_err;
  unsigned char temp;

  if(x1>x2) {
    temp=x1; x1=x2; x2=temp;
  }
  if(y1>y2) {
    temp=y1; y1=y2; y2=temp;
  } 
  ESP_LOGD(TAG, "x1=%d x2=%d delta=%d r=%d",x1, x2, x2-x1, r);
  ESP_LOGD(TAG, "y1=%d y2=%d delta=%d r=%d",y1, y2, y2-y1, r);
  if (x2-x1 < r) return; 
  if (y2-y1 < r) return; 

  x=0;
  y=-r;
  err=2-2*r;
  do{
    if(x) {
      lcdDrawPixel(dev, x1+r-x, y1+r+y, color); 
      lcdDrawPixel(dev, x2-r+x, y1+r+y, color); 
      lcdDrawPixel(dev, x1+r-x, y2-r-y, color); 
      lcdDrawPixel(dev, x2-r+x, y2-r-y, color);
    } // endif 
    if ((old_err=err)<=x)  err+=++x*2+1;
    if (old_err>y || err>x) err+=++y*2+1;   
  } while(y<0);
  ESP_LOGD(TAG, "x1+r=%d x2-r=%d",x1+r, x2-r);
  lcdDrawLine(dev, x1+r,y1  ,x2-r,y1  ,color);
  lcdDrawLine(dev, x1+r,y2  ,x2-r,y2  ,color);
  ESP_LOGD(TAG, "y1+r=%d y2-r=%d",y1+r, y2-r);
  lcdDrawLine(dev, x1  ,y1+r,x1  ,y2-r,color);
  lcdDrawLine(dev, x2  ,y1+r,x2  ,y2-r,color);  
} 

// 用颜色画箭头
void lcdDrawArrow(TFT_t * dev, uint16_t x0,uint16_t y0,uint16_t x1,uint16_t y1,uint16_t w,uint16_t color) {
  double Vx= x1 - x0;
  double Vy= y1 - y0;
  double v = sqrt(Vx*Vx+Vy*Vy);
  double Ux= Vx/v;
  double Uy= Vy/v;

  uint16_t L[2],R[2];
  L[0]= x1 - Uy*w - Ux*v;
  L[1]= y1 + Ux*w - Uy*v;
  R[0]= x1 + Uy*w - Ux*v;
  R[1]= y1 - Ux*w - Uy*v;
  lcdDrawLine(dev, x1, y1, L[0], L[1], color);
  lcdDrawLine(dev, x1, y1, R[0], R[1], color);
  lcdDrawLine(dev, L[0], L[1], R[0], R[1], color);
}

// 绘制填充颜色的箭头
void lcdDrawFillArrow(TFT_t * dev, uint16_t x0,uint16_t y0,uint16_t x1,uint16_t y1,uint16_t w,uint16_t color) {
  double Vx= x1 - x0;
  double Vy= y1 - y0;
  double v = sqrt(Vx*Vx+Vy*Vy);
  double Ux= Vx/v;
  double Uy= Vy/v;

  uint16_t L[2],R[2];
  L[0]= x1 - Uy*w - Ux*v;
  L[1]= y1 + Ux*w - Uy*v;
  R[0]= x1 + Uy*w - Ux*v;
  R[1]= y1 - Ux*w - Uy*v;

  lcdDrawLine(dev, x0, y0, x1, y1, color);
  lcdDrawLine(dev, x1, y1, L[0], L[1], color);
  lcdDrawLine(dev, x1, y1, R[0], R[1], color);
  lcdDrawLine(dev, L[0], L[1], R[0], R[1], color);

  int ww;
  for(ww=w-1;ww>0;ww--) {
    L[0]= x1 - Uy*ww - Ux*v;
    L[1]= y1 + Ux*ww - Uy*v;
    R[0]= x1 + Uy*ww - Ux*v;
    R[1]= y1 - Ux*ww - Uy*v;
    lcdDrawLine(dev, x1, y1, L[0], L[1], color);
    lcdDrawLine(dev, x1, y1, R[0], R[1], color);
  }
}

// 用颜色绘制 ASCII 字符
int lcdDrawChar(TFT_t * dev, FontxFile *fxs, uint16_t x, uint16_t y, uint8_t ascii, uint16_t color) {
  uint16_t xx,yy,bit,ofs;
  unsigned char fonts[128]; // font pattern
  unsigned char pw, ph;
  int h,w;
  uint16_t mask;
  bool rc;

  if(_DEBUG_)printf("字体方向=%d\n",dev->_font_direction);
  rc = GetFontx(fxs, ascii, fonts, &pw, &ph);
  if(_DEBUG_)printf("GetFontx rc=%d pw=%d ph=%d\n",rc,pw,ph);
  if (!rc) return 0;
  int16_t xd1 = 0;
  int16_t yd1 = 0;
  int16_t xd2 = 0;
  int16_t yd2 = 0;
  uint16_t xss = 0;
  uint16_t yss = 0;
  int16_t xsd = 0;
  int16_t ysd = 0;
  int16_t next = 0;
  uint16_t x0  = 0;
  uint16_t x1  = 0;
  uint16_t y0  = 0;
  uint16_t y1  = 0;
  if (dev->_font_direction == 0) {
    xd1 = +1;
    yd1 = +1; //-1;
    xd2 =  0;
    yd2 =  0;
    xss =  x;
    yss =  y - (ph - 1);
    xsd =  1;
    ysd =  0;
    next = x + pw;
    x0  = x;
    y0  = y - (ph-1);
    x1  = x + (pw-1);
    y1  = y;
  } else if (dev->_font_direction == 2) {
    xd1 = -1;
    yd1 = -1; //+1;
    xd2 =  0;
    yd2 =  0;
    xss =  x;
    yss =  y + ph + 1;
    xsd =  1;
    ysd =  0;
    next = x - pw;
    x0  = x - (pw-1);
    y0  = y;
    x1  = x;
    y1  = y + (ph-1);
  } else if (dev->_font_direction == 1) {
    xd1 =  0;
    yd1 =  0;
    xd2 = -1;
    yd2 = +1; //-1;
    xss =  x + ph;
    yss =  y;
    xsd =  0;
    ysd =  1;
    next = y + pw; //y - pw;
    x0  = x;
    y0  = y;
    x1  = x + (ph-1);
    y1  = y + (pw-1);
  } else if (dev->_font_direction == 3) {
    xd1 =  0;
    yd1 =  0;
    xd2 = +1;
    yd2 = -1; //+1;
    xss =  x - (ph - 1);
    yss =  y;
    xsd =  0;
    ysd =  1;
    next = y - pw; //y + pw;
    x0  = x - (ph-1);
    y0  = y - (pw-1);
    x1  = x;
    y1  = y;
  }
  if (dev->_font_fill) lcdDrawFillRect(dev, x0, y0, x1, y1, dev->_font_fill_color);
  int bits;
  if(_DEBUG_)printf("xss=%d yss=%d\n",xss,yss);
  ofs = 0;
  yy = yss;
  xx = xss;
  for(h=0;h<ph;h++) {
    if(xsd) xx = xss;
    if(ysd) yy = yss;
    bits = pw;
    for(w=0;w<((pw+4)/8);w++) {
      mask = 0x80;
      for(bit=0;bit<8;bit++) {
        bits--;
        if (bits < 0) continue;
        if (fonts[ofs] & mask) {
          lcdDrawPixel(dev, xx, yy, color);
        } else {
          //if (dev->_font_fill) lcdDrawPixel(dev, xx, yy, dev->_font_fill_color);
        }
        if (h == (ph-2) && dev->_font_underline)
          lcdDrawPixel(dev, xx, yy, dev->_font_underline_color);
        if (h == (ph-1) && dev->_font_underline)
          lcdDrawPixel(dev, xx, yy, dev->_font_underline_color);
        xx = xx + xd1;
        yy = yy + yd2;
        mask = mask >> 1;
      }
      ofs++;
    }
    yy = yy + yd1;
    xx = xx + xd2;
  }
  if (next < 0) next = 0;
  return next;
}

// 用颜色绘制字符串
int lcdDrawString(TFT_t * dev, FontxFile *fx, uint16_t x, uint16_t y, uint8_t * ascii, uint16_t color) {
  int length = strlen((char *)ascii);
  if(_DEBUG_)printf("lcdDrawString length=%d\n",length);
  for(int i=0;i<length;i++) {
    if(_DEBUG_)printf("ascii[%d]=%x x=%d y=%d\n",i,ascii[i],x,y);
    if (dev->_font_direction == 0)
      x = lcdDrawChar(dev, fx, x, y, ascii[i], color);
    if (dev->_font_direction == 1)
      y = lcdDrawChar(dev, fx, x, y, ascii[i], color);
    if (dev->_font_direction == 2)
      x = lcdDrawChar(dev, fx, x, y, ascii[i], color);
    if (dev->_font_direction == 3)
      y = lcdDrawChar(dev, fx, x, y, ascii[i], color);
  }
  if (dev->_font_direction == 0) return x;
  if (dev->_font_direction == 2) return x;
  if (dev->_font_direction == 1) return y;
  if (dev->_font_direction == 3) return y;
  return 0;
}

// 用颜色绘制非字母数字字符 code:字符代码
int lcdDrawCode(TFT_t * dev, FontxFile *fx, uint16_t x,uint16_t y,uint8_t code,uint16_t color) {
  if(_DEBUG_)printf("code=%x x=%d y=%d\n",code,x,y);
  if (dev->_font_direction == 0)
    x = lcdDrawChar(dev, fx, x, y, code, color);
  if (dev->_font_direction == 1)
    y = lcdDrawChar(dev, fx, x, y, code, color);
  if (dev->_font_direction == 2)
    x = lcdDrawChar(dev, fx, x, y, code, color);
  if (dev->_font_direction == 3)
    y = lcdDrawChar(dev, fx, x, y, code, color);
  if (dev->_font_direction == 0) return x;
  if (dev->_font_direction == 2) return x;
  if (dev->_font_direction == 1) return y;
  if (dev->_font_direction == 3) return y;
  return 0;
}

#if 0
// Draw UTF8 character
// x:X coordinate
// y:Y coordinate
// utf8:UTF8 code
// color:color
int lcdDrawUTF8Char(TFT_t * dev, FontxFile *fx, uint16_t x,uint16_t y,uint8_t *utf8,uint16_t color) {
  uint16_t sjis[1];

  sjis[0] = UTF2SJIS(utf8);
  if(_DEBUG_)printf("sjis=%04x\n",sjis[0]);
  return lcdDrawSJISChar(dev, fx, x, y, sjis[0], color);
}

// Draw UTF8 string
// x:X coordinate
// y:Y coordinate
// utfs:UTF8 string
// color:color
int lcdDrawUTF8String(TFT_t * dev, FontxFile *fx, uint16_t x, uint16_t y, unsigned char *utfs, uint16_t color) {

  int i;
  int spos;
  uint16_t sjis[64];
  spos = String2SJIS(utfs, strlen((char *)utfs), sjis, 64);
  if(_DEBUG_)printf("spos=%d\n",spos);
  for(i=0;i<spos;i++) {
    if(_DEBUG_)printf("sjis[%d]=%x y=%d\n",i,sjis[i],y);
    if (dev->_font_direction == 0)
      x = lcdDrawSJISChar(dev, fx, x, y, sjis[i], color);
    if (dev->_font_direction == 1)
      y = lcdDrawSJISChar(dev, fx, x, y, sjis[i], color);
    if (dev->_font_direction == 2)
      x = lcdDrawSJISChar(dev, fx, x, y, sjis[i], color);
    if (dev->_font_direction == 3)
      y = lcdDrawSJISChar(dev, fx, x, y, sjis[i], color);
  }
  if (dev->_font_direction == 0) return x;
  if (dev->_font_direction == 2) return x;
  if (dev->_font_direction == 1) return y;
  if (dev->_font_direction == 3) return y;
  return 0;
}
#endif

// 设置字体方向
void lcdSetFontDirection(TFT_t * dev, uint16_t dir) {
  dev->_font_direction = dir;
}

// 设置字体填充颜色
// color:fill color
void lcdSetFontFill(TFT_t * dev, uint16_t color) {
  dev->_font_fill = true;
  dev->_font_fill_color = color;
}

// 取消设置字体填充
void lcdUnsetFontFill(TFT_t * dev) {
  dev->_font_fill = false;
}

// 设置字体下划线颜色
// color:frame color
void lcdSetFontUnderLine(TFT_t * dev, uint16_t color) {
  dev->_font_underline = true;
  dev->_font_underline_color = color;
}

// 取消设置字体下划线
void lcdUnsetFontUnderLine(TFT_t * dev) {
  dev->_font_underline = false;
}

// 设置字体自动下一行
void lcdWrapArround(TFT_t * dev, SCROLL_TYPE_t scroll, int start, int end) {
  if (dev->_use_frame_buffer == false) return;
  
  int _width = dev->_width;
  int _height = dev->_height;
  int32_t index1;
  int32_t index2;

  if (scroll == SCROLL_RIGHT) {
    uint16_t wk[_width];
    for (int i=start;i<end;i++) {
      index1 = i * _width;
      memcpy((char *)wk, (char*)&dev->_frame_buffer[index1], _width*2);
      index2 = index1 + _width - 1;
      dev->_frame_buffer[index1] = dev->_frame_buffer[index2];
      memcpy((char *)&dev->_frame_buffer[index1+1], (char *)&wk[0], (_width-1)*2);
    }
  } else if (scroll == SCROLL_LEFT) {
    uint16_t wk[_width];
    for (int i=start;i<end;i++) {
      index1 = i * _width;
      memcpy((char *)wk, (char*)&dev->_frame_buffer[index1], _width*2);
      index2 = index1 + _width - 1;
      dev->_frame_buffer[index2] = dev->_frame_buffer[index1];
      memcpy((char *)&dev->_frame_buffer[index1], (char *)&wk[1], (_width-1)*2);
    }
  } else if (scroll == SCROLL_UP) {
    uint16_t wk;
    for (int i=start;i<=end;i++) {
      wk = dev->_frame_buffer[i];
      for (int j=0;j<_height-1;j++) {
        index1 = j * _width + i;
        index2 = (j+1) * _width + i;
        dev->_frame_buffer[index1] = dev->_frame_buffer[index2];
      }
      index2 = (_height-1) * _width + i;
      dev->_frame_buffer[index2] = wk;
    }
  } else if (scroll == SCROLL_DOWN) {
    uint16_t wk;
    for (int i=start;i<=end;i++) {
      index2 = (_height-1) * _width + i;
      wk = dev->_frame_buffer[index2];
      for (int j=_height-2;j>=0;j--) {
        index1 = j * _width + i;
        index2 = (j+1) * _width + i;
        dev->_frame_buffer[index2] = dev->_frame_buffer[index1];
      }
      dev->_frame_buffer[i] = wk;
    }
  }
}

// 反转为矩形区域
void lcdInversionArea(TFT_t * dev, uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t *save) {
  if (x1 >= dev->_width) return;
  if (x2 >= dev->_width) x2=dev->_width-1;
  if (y1 >= dev->_height) return;
  if (y2 >= dev->_height) y2=dev->_height-1;

  int index = 0;
  ESP_LOGD(TAG,"offset(x)=%d offset(y)=%d",dev->_offsetx,dev->_offsety);
  if (dev->_use_frame_buffer) {
    for (int16_t j = y1; j <= y2; j++){
      for(int16_t i = x1; i <= x2; i++){
        if (save) save[index++] = dev->_frame_buffer[j*dev->_width+i];
        dev->_frame_buffer[j*dev->_width+i] = ~dev->_frame_buffer[j*dev->_width+i];
      }
    }
  } else {
    ESP_LOGW(TAG,"To use this feature, enable the FrameBuffer option.");
  }
}

// 从帧缓冲区获取矩形区域
void lcdGetRect(TFT_t * dev, uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t *save) {
  if (x1 >= dev->_width) return;
  if (x2 >= dev->_width) x2=dev->_width-1;
  if (y1 >= dev->_height) return;
  if (y2 >= dev->_height) y2=dev->_height-1;

  int index = 0;
  ESP_LOGD(TAG,"offset(x)=%d offset(y)=%d",dev->_offsetx,dev->_offsety);
  if (dev->_use_frame_buffer) {
    for (int16_t j = y1; j <= y2; j++){
      for(int16_t i = x1; i <= x2; i++){
        save[index++] = dev->_frame_buffer[j*dev->_width+i];
      }
    }
  } else {
    ESP_LOGW(TAG,"Disable frame buffer");
  }
}

// 将矩形区域设置为帧缓冲区
void lcdSetRect(TFT_t * dev, uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t *save) {
  if (x1 >= dev->_width) return;
  if (x2 >= dev->_width) x2=dev->_width-1;
  if (y1 >= dev->_height) return;
  if (y2 >= dev->_height) y2=dev->_height-1;

  int index = 0;
  ESP_LOGD(TAG,"offset(x)=%d offset(y)=%d",dev->_offsetx,dev->_offsety);
  if (dev->_use_frame_buffer) {
    for (int16_t j = y1; j <= y2; j++){
      for(int16_t i = x1; i <= x2; i++){
        dev->_frame_buffer[j*dev->_width+i] = save[index++];
      }
    }
  } else {
    ESP_LOGW(TAG,"Disable frame buffer");
  }
}

// 画圆作为光标
void lcdSetCursor(TFT_t * dev, uint16_t x0, uint16_t y0, uint16_t r, uint16_t color, uint16_t *save) {
  lcdGetRect(dev, x0-r, y0-r, x0+r, y0+r, save);
  lcdDrawCircle(dev, x0, y0, r, color);
}

// 重置光标
void lcdResetCursor(TFT_t * dev, uint16_t x0, uint16_t y0, uint16_t r, uint16_t color, uint16_t *save) {
  lcdSetRect(dev, x0-r, y0-r, x0+r, y0+r, save);
}

void JPEGReader(TFT_t * dev, char * file, int width, int height) {
  pixel_jpeg **pixels;
  int imageWidth;
  int imageHeight;
  esp_err_t err = decode_jpeg(&pixels, file, width, height, &imageWidth, &imageHeight);
  ESP_LOGI(TAG, "解码图像错误=%d 图像宽度=%d 图像高度=%d", err, imageWidth, imageHeight);
  if (err == ESP_OK) {
    uint16_t _width = width;
    uint16_t _cols = 0;
    if (width > imageWidth) {
      _width = imageWidth;
      _cols = (width - imageWidth) / 2;
    }
    ESP_LOGI(TAG, "宽度=%d 列=%d", _width, _cols);
    uint16_t _height = height;
    uint16_t _rows = 0;
    if (height > imageHeight) {
      _height = imageHeight;
      _rows = (height - imageHeight) / 2;
    }
    ESP_LOGI(TAG, "高度=%d 行=%d", _height, _rows);
    // 分配内存
    uint16_t *colors = (uint16_t*)malloc(sizeof(uint16_t) * _width);
    if (colors == NULL) {
      ESP_LOGI(TAG, "为颜色分配内存时出错");
      return;
    }
    for(int y = 0; y < _height; y++){
      for(int x = 0;x < _width; x++){
        colors[x] = pixels[y][x];
      }
      lcdDrawMultiPixels(dev, _cols, y+_rows, _width, colors);
      vTaskDelay(1);
    }
    lcdDrawFinish(dev);
    free(colors);
    release_image(&pixels, width, height);
    ESP_LOGI(TAG, "完成");
  } else {
    ESP_LOGI(TAG, "解码 Jpeg 失败=%d", err);
  }
}

void PNGReader(TFT_t * dev, char * file, int width, int height) {
  // 打开 PNG 文件
  FILE* fp = fopen(file, "rb");
  if (fp == NULL) {
    ESP_LOGW(__FUNCTION__, "未找到文件[%s]", file);
    return;
  }
  char buf[1024];
  size_t remain = 0;
  int len;
  pngle_t *pngle = pngle_new(width, height);
  pngle_set_init_callback(pngle, png_init);
  pngle_set_draw_callback(pngle, png_draw);
  pngle_set_done_callback(pngle, png_finish);
  double display_gamma = 2.2;
  pngle_set_display_gamma(pngle, display_gamma);
  while (!feof(fp)) {
    if (remain >= sizeof(buf)) {
      ESP_LOGE(__FUNCTION__, "缓冲区超出");
      while(1) vTaskDelay(1);
    }
    len = fread(buf + remain, 1, sizeof(buf) - remain, fp);
    if (len <= 0) {
      ESP_LOGI(TAG, "文件结束");
      break;
    }
    int fed = pngle_feed(pngle, buf, remain + len);
    if (fed < 0) {
      ESP_LOGE(__FUNCTION__, "错误; %s", pngle_error(pngle));
      while(1) vTaskDelay(1);
    }
    remain = remain + len - fed;
    if (remain > 0) memmove(buf, buf + fed, remain);
  }
  fclose(fp);

  uint16_t _width = width;
  uint16_t _cols = 0;
  if (width > pngle->imageWidth) {
    _width = pngle->imageWidth;
    _cols = (width - pngle->imageWidth) / 2;
  }
  ESP_LOGD(__FUNCTION__, "宽度=%d 列=%d", _width, _cols);

  uint16_t _height = height;
  uint16_t _rows = 0;
  if (height > pngle->imageHeight) {
      _height = pngle->imageHeight;
      _rows = (height - pngle->imageHeight) / 2;
  }
  ESP_LOGD(__FUNCTION__, "高度=%d 行=%d", _height, _rows);
  // 分配内存
  uint16_t *colors = (uint16_t*)malloc(sizeof(uint16_t) * _width);
  if (colors == NULL) {
    ESP_LOGE(__FUNCTION__, "为颜色分配内存时出错");
    return;
  }

#if 0
  for(int y = 0; y < _height; y++){
    for(int x = 0;x < _width; x++){
      pixel_png pixel = pngle->pixels[y][x];
      uint16_t color = rgb565(pixel.red, pixel.green, pixel.blue);
      lcdDrawPixel(dev, x+_cols, y+_rows, color);
    }
  }
#endif
  for(int y = 0; y < _height; y++){
    for(int x = 0;x < _width; x++){
      colors[x] = pngle->pixels[y][x];
    }
    lcdDrawMultiPixels(dev, _cols, y+_rows, _width, colors);
    vTaskDelay(1);
  }
  lcdDrawFinish(dev);
  free(colors);
  pngle_destroy(pngle, width, height);
}

void lcdAddStringList(TFT_t * dev, FontxFile *fx, uint16_t color, int direction, char** string, int number) {
  uint8_t buffer[FontxGlyphBufSize];
  uint8_t fontWidth;
  uint8_t fontHeight;
  GetFontx(fx, 0, buffer, &fontWidth, &fontHeight);
  uint8_t ascii[20];
  lcdSetFontDirection(dev, direction);
  for(int i=1;i<=number;i++)
  {  
    strcpy((char *)ascii, string[i-1]);
    lcdDrawString(dev, fx, 0, fontHeight*i-1, ascii, color);
  }
}

void lcdAddStringRow(TFT_t * dev, FontxFile *fx, uint16_t color, int direction, char* string, int row) {
  uint8_t buffer[FontxGlyphBufSize];
  uint8_t fontWidth;
  uint8_t fontHeight;
  GetFontx(fx, 0, buffer, &fontWidth, &fontHeight);
  uint8_t ascii[20];
  lcdSetFontDirection(dev, direction);
  strcpy((char *)ascii, string);
  lcdDrawString(dev, fx, 0, fontHeight*row-1, ascii, color);
}

void lcdAddStringXY(TFT_t * dev, FontxFile *fx, uint16_t color, int direction, char* string, uint16_t x, uint16_t y) {
  uint8_t buffer[FontxGlyphBufSize];
  uint8_t fontWidth;
  uint8_t fontHeight;
  GetFontx(fx, 0, buffer, &fontWidth, &fontHeight);
  uint8_t ascii[20];
  lcdSetFontDirection(dev, direction);
  strcpy((char *)ascii, string);
  lcdDrawString(dev, fx, x, y+fontHeight-1, ascii, color);
}