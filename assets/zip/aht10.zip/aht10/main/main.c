#include <freertos/FreeRTOS.h>
#include <esp_log.h>
#include "driver/i2c_master.h"

#define I2C_MASTER_SCL_IO     19
#define I2C_MASTER_SDA_IO     18 
#define SLAVE_ADDRESS_AHT     0x38    
#define SLAVE_ADDRESS_AHT_R   0x71 
#define SLAVE_ADDRESS_AHT_W   0x70 
#define I2C_NUM_0             0

//----- ESP I2C v5.31 --------------
i2c_master_bus_handle_t bus_handle;
i2c_master_bus_config_t i2c_mst_config = {
  .clk_source = I2C_CLK_SRC_DEFAULT,
  .i2c_port = I2C_NUM_0,
  .scl_io_num = I2C_MASTER_SCL_IO,
  .sda_io_num = I2C_MASTER_SDA_IO,
  .glitch_ignore_cnt = 7,
  .flags.enable_internal_pullup = true,
};
// --- 读 / 写 / 写和读功能 ---
void i2c_send_cmd (i2c_master_dev_handle_t handle, uint8_t* cmd, uint8_t length)
{
  ESP_ERROR_CHECK(i2c_master_transmit(handle, cmd, length, -1));
}

void i2c_get_data (i2c_master_dev_handle_t handle, uint8_t* data, uint8_t length)
{
  ESP_ERROR_CHECK(i2c_master_receive(handle, data, length, -1));
}

void i2c_cmd_data (i2c_master_dev_handle_t handle, uint8_t* cmd, uint8_t cmd_length, uint8_t* data, uint8_t data_length)
{
ESP_ERROR_CHECK(i2c_master_transmit_receive(handle, cmd, cmd_length, data, data_length, -1));
}
// ----- AHT10 --------------
i2c_master_dev_handle_t aht10_handle;
i2c_device_config_t aht10_cfg = {
  .dev_addr_length = I2C_ADDR_BIT_LEN_7,
  .device_address = SLAVE_ADDRESS_AHT,
  .scl_speed_hz = 100000,
};
// ----- 杂项功能 --------------
void msleep(int delay_ms)
{
  vTaskDelay(delay_ms/portTICK_PERIOD_MS);
}
void printHex(uint8_t value)
{
  printf("|0x%.8x|\n", value);
}
//-----------------------
void AHT10(float *temperature, float *humidity)
{
  uint8_t calibrate[4] = {SLAVE_ADDRESS_AHT_W, 0xE1, 0x08, 0x00};
  uint8_t measure[4] = {SLAVE_ADDRESS_AHT_W, 0xAC, 0x33, 0x00};
  uint8_t read[1] = {SLAVE_ADDRESS_AHT_W};
  uint8_t data[6] = {0, 0, 0, 0, 0, 0};
  uint8_t reset[2] = {SLAVE_ADDRESS_AHT_W, 0xBA};

  i2c_send_cmd(aht10_handle, &calibrate[0], 4);
  i2c_send_cmd(aht10_handle, &measure[0], 4);
  i2c_send_cmd(aht10_handle, &read[0], 1);
  i2c_get_data(aht10_handle, &data[0], 6);
  while ((data[0] & 0x08) != 0x08)
  {
    i2c_send_cmd(aht10_handle, &reset[0], 2);
    i2c_send_cmd(aht10_handle, &calibrate[0], 4);
    i2c_send_cmd(aht10_handle, &measure[0], 4);
    i2c_cmd_data(aht10_handle, &read[0], 1, &data[0], 6);
    msleep(100);
  } 
  while ((data[0] & 0x80) != 0x80)
  {
    i2c_send_cmd(aht10_handle, &measure[0], 4);
    i2c_cmd_data(aht10_handle, &read[0], 1, &data[0], 6);
    msleep(100);
  } 
  int64_t H1 = (data[1] << 12) | (data[2] << 4) | (data[3] >> 4) ;
  H1 = (H1 * 10000) >> 20;
  int64_t T1 = ((data[3] & 0x0F) << 16) | (data[4] << 8) | data[5];
  T1 = ((T1 * 20000) >> 20) - 5000;
  *temperature = T1 / 100.0;
  *humidity = H1 / 100.0;
}

void app_main(void)
{
  float temperature=0.0;
  float humidity=0.0;
  ESP_ERROR_CHECK(i2c_new_master_bus(&i2c_mst_config, &bus_handle));
  ESP_ERROR_CHECK(i2c_master_bus_add_device(bus_handle, &aht10_cfg, &aht10_handle));
  printf("I2C initialized successfully...\n");
  while(true)
  {
    AHT10(&temperature, &humidity);
    printf("温度:%3.3lf, 湿度:%3.3lf\n", temperature, humidity);
    msleep(1000);
  }
  printf("Success...\n");
  ESP_ERROR_CHECK(i2c_master_bus_rm_device(aht10_handle));
  ESP_ERROR_CHECK(i2c_del_master_bus(bus_handle));
  printf("I2C closed.\n");
}