#ifndef ESP_WIFI_H_
#define ESP_WIFI_H_

#define TAG         "WIFI"
#define STA_SSID    "dickyko"
#define PASSWORD    "xxxxxxxx"
#define SNTP_SERVER "stdtime.gov.hk"

const static char http_html_hdr[] = // 200 成功标头
    "HTTP/1.1 200 OK\nContent-Type: application/json\nContent-Length: 19\n{\"success\":\"true\"}";

const static char http_404_hdr[] =  // 404 失败标头
    "HTTP/1.1 404 Not Found\r\nContent-type: text/html\r\n\r\n";

void wifi_connection();
void sntp(char* sntpServer);

#endif /* ESP_WIFI_H_ */