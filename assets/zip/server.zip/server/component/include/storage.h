#ifndef ESP_STORAGE_H_
#define ESP_STORAGE_H_

#define TAG "SPIFFS"

typedef struct {
    char   *p;
    size_t n;
} fileInfo;

char* concat(const char *s1, const char *s2);
void mount_SPIFFS();
void SPIFFS_Directory(char * path);
bool readFile(char* filename, fileInfo* data);
bool saveFile(char* filename, char* data, bool append);
bool renameFile(char* srcfilename, char* filename);
bool removeFile(char* filename);

#endif /* ESP_STORAGE_H_ */