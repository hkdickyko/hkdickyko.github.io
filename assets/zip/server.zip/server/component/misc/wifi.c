#include <stdio.h>              //用于基本 printf 命令
#include <string.h>             //用于处理字符串
#include "freertos/FreeRTOS.h"  //用于 延迟、互斥、信号量 实时操作系统操作
#include "esp_system.h"         //esp_init 函数 esp_err_t
#include "esp_wifi.h"           //esp_wifi_init 函数和 wifi 操作
#include "esp_log.h"            //用于显示日志
#include "esp_event.h"          //用于 wifi 事件
#include "lwip/err.h"           //轻量级 IP 数据包错误处理
#include "lwip/sys.h"           //用于轻量级 IP 应用的系统应用程序
#include "esp_netif_sntp.h"
#include "esp_sntp.h"

#include "../include/wifi.h"

static void wifi_event_handler(void *event_handler_arg, esp_event_base_t event_base, int32_t event_id,void *event_data)
{
  int retry_num=0;
  if(event_id == WIFI_EVENT_STA_START)
  {
    ESP_LOGI(TAG, "WIFI 连接...");
  }
  else if (event_id == WIFI_EVENT_STA_CONNECTED)
  {
    ESP_LOGI(TAG, "WiFi 已连接");
  }
  else if (event_id == WIFI_EVENT_STA_DISCONNECTED)
  {
    ESP_LOGI(TAG, "WiFi 失去连接");
    if(retry_num<5)
    {
      esp_wifi_connect();
      retry_num++;
      ESP_LOGI(TAG, "重试连接...");}
  }
  else if (event_id == IP_EVENT_STA_GOT_IP)
  {
    ESP_LOGI(TAG, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    esp_netif_ip_info_t ip_info;
    esp_netif_get_ip_info(IP_EVENT_STA_GOT_IP,&ip_info);
    ESP_LOGI(TAG,"IP: " IPSTR, IP2STR(&ip_info.ip));
    ESP_LOGI(TAG,"网关: " IPSTR, IP2STR(&ip_info.gw));
    ESP_LOGI(TAG,"网络掩码: " IPSTR, IP2STR(&ip_info.netmask));
    ESP_LOGI(TAG, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
  }
}

void wifi_connection()
{
  esp_netif_init();                    // Wi-Fi 配置阶段
  esp_event_loop_create_default();     // 事件循环
  esp_netif_create_default_wifi_sta(); // WiFi 站
  wifi_init_config_t wifi_initiation = WIFI_INIT_CONFIG_DEFAULT();
  esp_wifi_init(&wifi_initiation);      
  esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, wifi_event_handler, NULL);
  esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP, wifi_event_handler, NULL);
  wifi_config_t wifi_configuration = {
      .sta = {
        .ssid = STA_SSID,
        .password = PASSWORD,
      }
    };
  ESP_LOGI(TAG, "Kconfig, SSID=%s, PASS=%s", STA_SSID, PASSWORD);
  esp_wifi_set_config(ESP_IF_WIFI_STA, &wifi_configuration);
  esp_wifi_start();                   // Wi-Fi 启动阶段
  esp_wifi_set_mode(WIFI_MODE_STA);
  esp_wifi_connect();                 // Wi-Fi 连接阶段
  ESP_LOGI(TAG, "wifi_init_softap finished. SSID:%s  password:%s",STA_SSID,PASSWORD);
}

void time_sync_notification_cb(struct timeval *tv_now)
{
  ESP_LOGI(TAG, "时间同步通知");
}

void currentTime(struct tm timeinfo)
{
  char strftime_buf[64];
  strftime(strftime_buf, sizeof(strftime_buf), "%c", &timeinfo);
  ESP_LOGI(TAG, "香港的当前日期/时间是: %s", strftime_buf);
}

void sntp(char* sntpServer)
{
  time_t now = 0;
  struct tm timeinfo = { 0 };
  int retry = 0;
  const int retry_count = 15;
  esp_sntp_config_t config = ESP_NETIF_SNTP_DEFAULT_CONFIG(sntpServer);
  config.start = true;                            // 启动 SNTP 服务
  config.server_from_dhcp = false;                // 接受来自 DHCP 服务器的 NTP 提供需要在连接之前启用
  config.renew_servers_after_new_IP = true;       // 在收到 DHCP 租约后更新配置的 SNTP 服务器
  config.index_of_first_server = 1;               // 来自服务器 1 的更新，保留服务器 0 不变
  config.ip_event_to_renew = IP_EVENT_STA_GOT_IP; // 配置我们更新服务器的事件
  config.sync_cb = time_sync_notification_cb;
  config.smooth_sync = false;
  esp_netif_sntp_init(&config);
  while (esp_netif_sntp_sync_wait(20000 / portTICK_PERIOD_MS) == ESP_ERR_TIMEOUT && ++retry < retry_count) 
  {
    ESP_LOGI(TAG, "等待设置系统时间... (%d/%d)", retry, retry_count);
  }
  if(retry < retry_count){
    time(&now);
    setenv("TZ", "CST-8", 1); // 将时区设置为中国标准时间
    tzset();  
    localtime_r(&now, &timeinfo);
    currentTime(timeinfo);
  }else{
    ESP_LOGI(TAG, "时间更新失败!");
  }
  esp_netif_sntp_deinit();
}