#include <stdio.h>              //用于基本 printf 命令
#include <string.h>             //用于处理字符串
#include <stdlib.h>
#include "freertos/FreeRTOS.h"  //用于 延迟、互斥、信号量 实时操作系统操作
#include "esp_system.h"         //esp_init 函数 esp_err_t
#include "esp_log.h"            //用于显示日志
#include "esp_event.h"          //用于 wifi 事件
#include "esp_vfs.h"
#include "esp_spiffs.h"

#include "../include/storage.h"

char* concat(const char *s1, const char *s2)
{
    const size_t len1 = strlen(s1);
    const size_t len2 = strlen(s2);
    char *lvalue = malloc(len1 + len2 + 1);
    memcpy(lvalue, s1, len1);
    memcpy(lvalue + len1, s2, len2 + 1);
    return lvalue;
}

void SPIFFS_Directory(char * path) {
  DIR* dir = opendir(path);
  assert(dir != NULL);
  while (true) {
    struct dirent* pe = readdir(dir);
    if (!pe) break;
    ESP_LOGI(TAG, "文件名=%s 节点编号=%d 文件类型=%x", pe->d_name,pe->d_ino, pe->d_type);
  }
  closedir(dir);
}

bool readFile(char* filename, fileInfo* data)
{
  struct stat st;
  char* result = NULL;
  static FILE *file = NULL;
  if (stat(filename, &st) == 0)
  {
    file = fopen(filename, "r");
    if(file != NULL){
      result = (char*) malloc(st.st_size+1 * sizeof(char));
      if(fgets(result, st.st_size, file) != NULL){
        data->p = result;
        data->n = st.st_size;
        fclose(file);
        return true;
      }
    }
    fclose(file);
  }
  ESP_LOGE(TAG, "文件 %s 不存在!", filename);
  return false;
}

bool saveFile(char* filename, char* data, bool append)
{
  static FILE *file = NULL;
  if(append){
    file = fopen(filename, "a");
  }else{
    file = fopen(filename, "w");
  }
  if(file != NULL){
    fprintf(file, data);
    fclose(file);
    return true;
  }
  fclose(file);
  ESP_LOGE(TAG, "文件 %s 写入失败!", filename);
  return false;
}

bool renameFile(char* srcfilename, char* filename)
{
  if (rename(srcfilename, filename) != 0) {
    ESP_LOGE(TAG, "文件 %s 重命名失败!", srcfilename);
    return false;
  }else{
    return true;
  }
}

bool removeFile(char* filename)
{
  struct stat st;
  if (stat(filename, &st) == 0) {
    unlink(filename);
    return true;
  }else{
    ESP_LOGE(TAG, "文件 %s 删除失败!", filename);
    return false;    
  }
}

void mount_SPIFFS()
{
  ESP_LOGI(TAG, "初始化 SPIFFS");
  esp_vfs_spiffs_conf_t conf = {
    .base_path = "/spiffs",
    .partition_label = NULL,
    .max_files = 12,
    .format_if_mount_failed =true
  };
  // 使用上面定义的设置来初始化和挂载 SPIFFS 文件系统
  esp_err_t ret = esp_vfs_spiffs_register(&conf);
  if (ret != ESP_OK) {
    if (ret == ESP_FAIL) {
      ESP_LOGI(TAG, "无法挂载或格式化文件系统");
    } else if (ret == ESP_ERR_NOT_FOUND) {
      ESP_LOGI(TAG, "找不到 SPIFFS 分区");
    } else {
      ESP_LOGI(TAG, "无法初始化 SPIFFS (%s)",esp_err_to_name(ret));
    }
    return;
  }
  size_t total = 0, used = 0;
  ret = esp_spiffs_info(NULL, &total,&used);
  if (ret != ESP_OK) {
    ESP_LOGI(TAG, "无法获取 SPIFFS 分区信息 (%s)",esp_err_to_name(ret));
  } else {
    ESP_LOGI(TAG, "分区大小总计: %d, 已用容量: %d", total, used);
  }
  SPIFFS_Directory("/spiffs/");
}