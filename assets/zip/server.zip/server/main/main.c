#include <stdio.h>              //用于基本 printf 命令
#include <string.h>             //用于处理字符串
#include <stdlib.h>
#include "freertos/FreeRTOS.h"  //用于 延迟、互斥、信号量 实时操作系统操作
#include "esp_system.h"         //esp_init 函数 esp_err_t
#include "esp_wifi.h"           //esp_wifi_init 函数和 wifi 操作
#include "esp_log.h"            //用于显示日志
#include "esp_event.h"          //用于 wifi 事件
#include "nvs_flash.h"          //非易失性存储
#include "lwip/err.h"           //轻量级 IP 数据包错误处理
#include "lwip/sys.h"           //用于轻量级 IP 应用的系统应用程序

#include "freertos/task.h"
#include "freertos/event_groups.h"

#include <lwip/sockets.h>
#include <lwip/sys.h>
#include <lwip/api.h>
#include <lwip/netdb.h>

#include "../component/include/wifi.h"
#include "../component/include/storage.h"

#define TAG "SERVER"

fileInfo result = {NULL, 0};

void msleep(int delay_ms)
{
  vTaskDelay(delay_ms/portTICK_PERIOD_MS);
}

static void http_server_netconn_serve(struct netconn *conn) {
  struct netbuf *inbuf;
  char *buf;
  u16_t buflen;
  err_t err;
  err = netconn_recv(conn, &inbuf);   // 从端口读取数据，如果尚未读取任何数据则阻塞。
  if (err == ERR_OK) {
    netbuf_data(inbuf, (void**) &buf, &buflen);
    // HTTP GET 命令吗？ 仅检查前 5 个字符，因为 GET 还有其他格式
    if (buflen >= 5 && strncmp("GET ",buf,4)==0) {
      char* path = NULL;                     // 解析 URL
      char* line_end = strchr(buf, '\n');
      if( line_end != NULL )
      {                                     // 从 HTTP GET 请求中提取路径
        path = (char*)malloc(sizeof(char)*(line_end-buf+1));
        int path_length = line_end - buf - strlen("GET ")-strlen("HTTP/1.1")-2;
        strncpy(path, &buf[4], path_length );
        path[path_length] = '\0';
        ip_addr_t remote_ip;                // 获取远程 IP 地址
        u16_t remote_port;
        netconn_getaddr(conn, &remote_ip, &remote_port, 0);
        ESP_LOGI(TAG, "[ "IPSTR" ] GET %s\n", IP2STR(&(remote_ip.u_addr.ip4)),path);
      }
      if(path != NULL)   				          	// 发送 HTML 内容
      {
        char* srcpath = concat("/spiffs", path);
        if(readFile(srcpath, &result))
        {
          netconn_write(conn, result.p, result.n - 1,  NETCONN_NOCOPY);
        }else{
          netconn_write(conn, http_404_hdr, sizeof(http_404_hdr) - 1, NETCONN_NOCOPY);
          }
        free(result.p);
        result.p=NULL;
        free(srcpath);
        free(path);
        path=NULL;
      }
    }
  }
  netconn_close(conn);  // 关闭连接
  netbuf_delete(inbuf); // 删除及释放缓冲区
}

static void http_server(void *pvParameters) {
  struct netconn *conn, *newconn;  // 监听线程，newconn 是客户端的新线程
  err_t err;
  conn = netconn_new(NETCONN_TCP);
  netconn_bind(conn, NULL, 80);
  netconn_listen(conn);
  do {
    err = netconn_accept(conn, &newconn);
    if (err == ERR_OK) {
      http_server_netconn_serve(newconn);
      netconn_delete(newconn);
    }
  } while (err == ERR_OK);
  netconn_close(conn);
  netconn_delete(conn);
}

void app_main(void)
{
nvs_flash_init();
mount_SPIFFS();
wifi_connection();
sntp(SNTP_SERVER);
removeFile("/spiffs/test1.txt");
renameFile("/spiffs/test.txt", "/spiffs/test1.txt");
saveFile("/spiffs/test.txt", "testing...", false);
xTaskCreate(&http_server, "http_server", 2048, NULL, 5, NULL);
}