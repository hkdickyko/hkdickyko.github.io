#include "freertos/FreeRTOS.h"
#include "esp_wifi.h"
#include "esp_system.h"
#include "esp_event.h"
#include "esp_event.h"
#include "nvs_flash.h"
#include "driver/gpio.h"
#include "./include/stepper.h"

void app_main(void)
{
    nvs_flash_init();
    double delay = 2;
    struct stepper_pins stepper0; // 步进电机的初始端口
    stepper0.pin1 = 27;
    stepper0.pin2 = 26;
    stepper0.pin3 = 25;
    stepper0.pin4 = 33;    
    stepper_init(&stepper0);
    steps(&stepper0, 2048, CCW, FULLSPEED, delay); // 逆时针旋转步进电机一圈
    steps(&stepper0, 2048, CW, FULLSPEED, delay);  // 顺时针旋转步进电机一圈
} 