#include <stdlib.h>
#include <string.h>
#include "driver/rmt_common.h"
#include "driver/rmt_encoder.h"
#include "driver/rmt_types.h"
#include "driver/rmt_tx.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "nvs_flash.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "esp_check.h"

#define CW 0
#define CCW 1
#define ON 0
#define OFF 1
#define TOTAL 100
#define TICK_FREQ 1000000 // 频率 1MHz
struct stepper_pins
{
  uint8_t ENA;
  uint8_t DIR;
  uint8_t PLU;
};
struct stepper_pins stepper0; 
static rmt_channel_handle_t txChannel;
static rmt_encoder_handle_t rfEncoder;
/************* 自定义函数 ******************/
int sfreq = 100;
int efreq = 1200;
static rmt_symbol_word_t symbols[TOTAL];

static float smoother(uint32_t x0, uint32_t x1, uint32_t x)
{
  float y = ((float)(x-x0))/(x1-x0);
  float smooth_x = y*y*y*(y*(6*y-15)+10);
  return smooth_x*(x1-x0)+x0;
}

void fit(int s_hz, int e_hz, int total)
{
  int tick;
  float freq;
  float steps = (e_hz-s_hz)/(total-1);
  for (int i=0; i<total; i++) 
  {
    freq = smoother(s_hz, e_hz, s_hz+steps*i);
    tick = TICK_FREQ/freq/2;
    printf("%d,", tick);
    symbols[i].level0 = 1;
    symbols[i].duration0 = tick;
    symbols[i].level1 = 0;
    symbols[i].duration1 = tick;
  }
}

void init_symbol()  
{
fit(sfreq,efreq,TOTAL); 
}

void init_tx_channel(int GPIO_NUM)
{
  rmt_tx_channel_config_t cfg = {
    .gpio_num = GPIO_NUM,
    .clk_src = RMT_CLK_SRC_DEFAULT,
    .resolution_hz = TICK_FREQ,
    .mem_block_symbols = 64,
    .trans_queue_depth = 4,
  };
  ESP_ERROR_CHECK(rmt_new_tx_channel(&cfg, &txChannel));
}

void init_encoder()   
{
  rmt_copy_encoder_config_t cfg = {};
  ESP_ERROR_CHECK(rmt_new_copy_encoder(&cfg, &rfEncoder));
}

void send_data() 
{
  rmt_transmit_config_t cfg = {.loop_count = 0 }; 
  ESP_ERROR_CHECK(rmt_transmit(txChannel, rfEncoder, symbols, sizeof(symbols), &cfg));
}

void app_main(void)
{
  nvs_flash_init();
  stepper0.ENA = 27;
  stepper0.DIR = 26;
  stepper0.PLU = 25;
  gpio_set_direction(stepper0.ENA, GPIO_MODE_OUTPUT);
  gpio_set_direction(stepper0.DIR, GPIO_MODE_OUTPUT);
  gpio_set_direction(stepper0.PLU, GPIO_MODE_OUTPUT);
  gpio_set_level(stepper0.ENA, ON);
  gpio_set_level(stepper0.DIR, CW);
  init_tx_channel(stepper0.PLU);          // 初始化通道
  init_symbol();                          // 初始化符号
  init_encoder();                         // 初始化编码器
  ESP_ERROR_CHECK(rmt_enable(txChannel)); // 使能通道
  send_data();
  ESP_ERROR_CHECK(rmt_tx_wait_all_done(txChannel, portMAX_DELAY));
  ESP_ERROR_CHECK(rmt_disable(txChannel)); 
  ESP_ERROR_CHECK(rmt_del_channel(txChannel));
  ESP_ERROR_CHECK(rmt_del_encoder(rfEncoder));
}