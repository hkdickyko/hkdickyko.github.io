#include <stdlib.h>
#include <string.h>
#include "driver/rmt_common.h"
#include "driver/rmt_encoder.h"
#include "driver/rmt_types.h"
#include "driver/rmt_tx.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "nvs_flash.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "esp_check.h"

// 声明区
#define CW 0
#define CCW 1
#define ON 0
#define OFF 1
#define TICK_FREQ 1000000 // 频率 1MHz
// 变量区
struct stepper_pins
{
  uint8_t ENA;
  uint8_t DIR;
  uint8_t PLU;
};
// 步进电机的初始端口
struct stepper_pins stepper0; 
/* 发送通道 */
static rmt_channel_handle_t txChannel;
/* 编码器 */
static rmt_encoder_handle_t rfEncoder;
/* 消息符号 */
static rmt_symbol_word_t symbols[1];
/************* 自定义函数 ******************/
void init_symbol(int i, int tick0, int tick1, int level0)  // 初始化符号
{
  double cycle_us = 1000000 / TICK_FREQ;
  symbols[i].duration0 = tick0 * cycle_us;
  symbols[i].level0 = level0;
  symbols[i].duration1 = tick1 * cycle_us;
  if(level0 == 0)
    symbols[i].level1 = 1;
  else
    symbols[i].level1 = 0;
}

void init_tx_channel(int GPIO_NUM)
{
  rmt_tx_channel_config_t cfg = {
    // GPIO
    .gpio_num = GPIO_NUM,
    // 时钟源：默认是APB
    .clk_src = RMT_CLK_SRC_DEFAULT,
    // 分辨率，即频率
    .resolution_hz = TICK_FREQ,
    // 内存大小，指的是符号个数，不是字节个数
    .mem_block_symbols = 64,
    // 传输队列深度，不要设得太大
    .trans_queue_depth = 4,
  };
  // 调用函数初始化
  ESP_ERROR_CHECK(rmt_new_tx_channel(&cfg, &txChannel));
}

void init_encoder()   // 初始化编码器
{
  // 目前配置不需要参数
  rmt_copy_encoder_config_t cfg = {};
  // 创建拷贝编码器
  ESP_ERROR_CHECK(rmt_new_copy_encoder(&cfg, &rfEncoder));
}

void send_data() // 发送数据
{
  rmt_transmit_config_t cfg = {.loop_count = 0 }; // 配置不循环发送
  // 发送
  ESP_ERROR_CHECK(rmt_transmit(txChannel, rfEncoder, symbols, sizeof(symbols), &cfg));
}

void app_main(void)
{
  nvs_flash_init();
  stepper0.ENA = 27;
  stepper0.DIR = 26;
  stepper0.PLU = 25;
  gpio_set_direction(stepper0.ENA, GPIO_MODE_OUTPUT);
  gpio_set_direction(stepper0.DIR, GPIO_MODE_OUTPUT);
  gpio_set_direction(stepper0.PLU, GPIO_MODE_OUTPUT);
  gpio_set_level(stepper0.ENA, ON);
  gpio_set_level(stepper0.DIR, CW);
  init_tx_channel(stepper0.PLU);          // 初始化通道
  init_symbol(0, 500,500,1);                         // 初始化符号
  init_encoder();                         // 初始化编码器
  ESP_ERROR_CHECK(rmt_enable(txChannel)); // 使能通道
  while (1)        
    send_data();
}