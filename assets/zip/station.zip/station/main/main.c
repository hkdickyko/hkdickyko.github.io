#include <stdio.h>              //用于基本 printf 命令
#include <string.h>             //用于处理字符串
#include "freertos/FreeRTOS.h"  //用于 延迟、互斥、信号量 实时操作系统操作
#include "esp_system.h"         //esp_init 函数 esp_err_t
#include "esp_wifi.h"           //esp_wifi_init 函数和 wifi 操作
#include "esp_log.h"            //用于显示日志
#include "esp_event.h"          //用于 wifi 事件
#include "nvs_flash.h"          //非易失性存储
#include "lwip/err.h"           //轻量级 IP 数据包错误处理
#include "lwip/sys.h"           //用于轻量级 IP 应用的系统应用程序

#define TAG "WIFI"
#define STA_SSID  "dickyko"
#define PASSWORD  "mp2ngpid5berbg3"

static void wifi_event_handler(void *event_handler_arg, esp_event_base_t event_base, int32_t event_id,void *event_data)
{
  int retry_num=0;
  if(event_id == WIFI_EVENT_STA_START)
  {
    ESP_LOGI(TAG, "WIFI 连接...");
  }
  else if (event_id == WIFI_EVENT_STA_CONNECTED)
  {
    ESP_LOGI(TAG, "WiFi 已连接");
  }
  else if (event_id == WIFI_EVENT_STA_DISCONNECTED)
  {
    ESP_LOGI(TAG, "WiFi 失去连接");
    if(retry_num<5)
    {
      esp_wifi_connect();
      retry_num++;
      ESP_LOGI(TAG, "重试连接...");}
  }
  else if (event_id == IP_EVENT_STA_GOT_IP)
  {
    ESP_LOGI(TAG, "WiFi 获取到 IP 了...");
  }
}

void wifi_connection()
{
  esp_netif_init();                    // Wi-Fi 配置阶段
  esp_event_loop_create_default();     // 事件循环
  esp_netif_create_default_wifi_sta(); // WiFi 站
  wifi_init_config_t wifi_initiation = WIFI_INIT_CONFIG_DEFAULT();
  esp_wifi_init(&wifi_initiation);      
  esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, wifi_event_handler, NULL);
  esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP, wifi_event_handler, NULL);
  wifi_config_t wifi_configuration = {
      .sta = {
        .ssid = STA_SSID,
        .password = PASSWORD,
      }
    };
  ESP_LOGI(TAG, "Kconfig, SSID=%s, PASS=%s", STA_SSID, PASSWORD);
  esp_wifi_set_config(ESP_IF_WIFI_STA, &wifi_configuration);
  esp_wifi_start();                   // Wi-Fi 启动阶段
  esp_wifi_set_mode(WIFI_MODE_STA);
  esp_wifi_connect();                 // Wi-Fi 连接阶段
  ESP_LOGI(TAG, "wifi_init_softap finished. SSID:%s  password:%s",STA_SSID,PASSWORD);
}

void app_main(void)
{
nvs_flash_init();
wifi_connection();
}