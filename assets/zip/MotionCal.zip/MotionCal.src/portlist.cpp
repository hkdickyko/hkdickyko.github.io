/*  Serial port object for use with wxWidgets
 *  Copyright 2010, Paul Stoffregen (paul@pjrc.com)
 */

#include "gui.h"

#include <sys/types.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/select.h>
#include <termios.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <linux/serial.h>
// All linux serial port device names.  Hopefully all of them anyway.  This
// is a long list, but each entry takes only a few bytes and a quick strcmp()
static const char *devnames[] = {
"USB",	// USB to serial converters
"S",	// "normal" Serial Ports - MANY drivers using this
"ACM",	// USB serial modem, CDC class, Abstract Control Model
"MI",	// MOXA Smartio/Industio family multiport serial... nice card, I have one :-)
"MX",	// MOXA Intellio family multiport serial
"C",	// Cyclades async multiport, no longer available, but I have an old ISA one! :-)
"D",	// Digiboard (still in 2.6 but no longer supported), new Moschip MCS9901
"P",	// Hayes ESP serial cards (obsolete)
"M",	// PAM Software's multimodem & Multitech ISI-Cards
"E",	// Stallion intelligent multiport (no longer made)
"L",	// RISCom/8 multiport serial
"W",	// specialix IO8+ multiport serial
"X",	// Specialix SX series cards, also SI & XIO series
"SR",	// Specialix RIO serial card 257+
"n",	// Digi International Neo (yes lowercase 'n', drivers/serial/jsm/jsm_driver.c)
"FB",	// serial port on the 21285 StrongArm-110 core logic chip
"AM",	// ARM AMBA-type serial ports (no DTR/RTS)
"AMA",	// ARM AMBA-type serial ports (no DTR/RTS)
"AT",	// Atmel AT91 / AT32 Serial ports
"BF",	// Blackfin 5xx serial ports (Analog Devices embedded DSP chips)
"CL",	// CLPS711x serial ports (ARM processor)
"A",	// ICOM Serial
"SMX",	// Motorola IMX serial ports
"SOIC",	// ioc3 serial
"IOC",	// ioc4 serial
"PSC",	// Freescale MPC52xx PSCs configured as UARTs
"MM",	// MPSC (UART mode) on Marvell GT64240, GT64260, MV64340...
"B",	// Mux console found in some PA-RISC servers
"NX",	// NetX serial port
"PZ",	// PowerMac Z85c30 based ESCC cell found in the "macio" ASIC
"SAC",	// Samsung S3C24XX onboard UARTs
"SA",	// SA11x0 serial ports
"AM",	// KS8695 serial ports & Sharp LH7A40X embedded serial ports
"TX",	// TX3927/TX4927/TX4925/TX4938 internal SIO controller
"SC",	// Hitachi SuperH on-chip serial module
"SG",	// C-Brick Serial Port (and console) SGI Altix machines
"HV",	// SUN4V hypervisor console
"UL",	// Xilinx uartlite serial controller
"VR",	// NEC VR4100 series Serial Interface Unit
"CPM",	// CPM (SCC/SMC) serial ports; core driver
"Y",	// Amiga A2232 board
"SL",	// Microgate SyncLink ISA and PCI high speed multiprotocol serial
"SLG",	// Microgate SyncLink GT (might be sync HDLC only?)
"SLM",	// Microgate SyncLink Multiport high speed multiprotocol serial
"CH",	// Chase Research AT/PCI-Fast serial card
"F",	// Computone IntelliPort serial card
"H",	// Chase serial card
"I",	// virtual modems
"R",	// Comtrol RocketPort
"SI",	// SmartIO serial card
"T",	// Technology Concepts serial card
"V",	// Comtrol VS-1000 serial controller
"i2c" 
};
#define NUM_DEVNAMES (sizeof(devnames) / sizeof(const char *))

// Return a list of all serial ports
wxArrayString serial_port_list()
{
	wxArrayString list;
	// This is ugly guessing, but Linux doesn't seem to provide anything else.
	// If there really is an API to discover serial devices on Linux, please
	// email paul@pjrc.com with the info.  Please?
	// The really BAD aspect is all ports get DTR raised briefly, because linux
	// has no way to open the port without raising DTR, and there isn't any way
	// to tell if the device file really represents hardware without opening it.
	// maybe sysfs or udev provides a useful API??
	DIR *dir;
	struct dirent *f;
	struct stat st;
	unsigned int i, len[NUM_DEVNAMES];
	char s[512];
	int fd, bits;
	termios mytios;

	dir = opendir("/dev/");
	if (dir == NULL) return list;
	for (i=0; i<NUM_DEVNAMES; i++) len[i] = strlen(devnames[i]);
	// Read all the filenames from the /dev directory...
	while ((f = readdir(dir)) != NULL) {
		// ignore everything that doesn't begin with "tty"
		if (strncmp(f->d_name, "tty", 3)) continue;
		// ignore anything that's not a known serial device name
		for (i=0; i<NUM_DEVNAMES; i++) {
			if (!strncmp(f->d_name + 3, devnames[i], len[i])) break;
		}
		if (i >= NUM_DEVNAMES) continue;
		snprintf(s, sizeof(s), "/dev/%s", f->d_name);
		// check if it's a character type device (almost certainly is)
		if (stat(s, &st) != 0 || !(st.st_mode & S_IFCHR)) continue;
		// now see if we can open the file - if the device file is
		// populating /dev but doesn't actually represent a loaded
		// driver, this is where we will detect it.
		fd = open(s, O_RDONLY | O_NOCTTY | O_NONBLOCK);
		if (fd < 0) {
			// if permission denied, give benefit of the doubt
			// (otherwise the port will be invisible to the user
			// and we won't have a to alert them to the permssion
			// problem)
			if (errno == EACCES) list.Add(s);
			// any other error, assume it's not a real device
			continue;
		}
		// does it respond to termios requests? (probably will since
		// the name began with tty).  Some devices where a single
		// driver exports multiple names will open but this is where
		// we can really tell if they work with real hardare.
		if (tcgetattr(fd, &mytios) != 0) {
			close(fd);
			continue;
		}
		// does it respond to reading the control signals?  If it's
		// some sort of non-serial terminal (eg, pseudo terminals)
		// this is where we will detect it's not really a serial port
		if (ioctl(fd, TIOCMGET, &bits) < 0) {
			close(fd);
			continue;
		}
		// it passed all the tests, it's a serial port, or some sort
		// of "terminal" that looks exactly like a real serial port!
		close(fd);
		// unfortunately, Linux always raises DTR when open is called.
		// not nice!  Every serial port is going to get DTR raised
		// and then lowered.  I wish there were a way to prevent this,
		// but it seems impossible.
		list.Add(s);
	}
	closedir(dir);

	list.Sort();
	// for(i=0;i<list.GetCount();i++)
  //    printf("--- %s,\n", static_cast<const char*>(list.Item(i).c_str()));
	return list;
}